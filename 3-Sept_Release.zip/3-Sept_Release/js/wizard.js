// Print Function for Print Button //
function printWizard() {
  window.print();
}